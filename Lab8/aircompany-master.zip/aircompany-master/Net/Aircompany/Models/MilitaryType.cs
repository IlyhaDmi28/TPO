﻿namespace Aircompany.Models
{
    public enum MilitaryType
    {
        FIGHTER,
        BOMBER,
        TRANSPORT
    }
}
