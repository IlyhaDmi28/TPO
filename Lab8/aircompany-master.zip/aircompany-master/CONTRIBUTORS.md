Java - original pretty version
=======================
* Sergei Volchek
* Aliaksei Safronau

Java - final corrupted version with voilations
=======================================
* Vitali Shulha

JS version
==========
* @SnezhanaMatskevich

C# version
==========
* @DenisChulkov