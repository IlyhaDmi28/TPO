const ExperimentalTypes   = {
    LIFTING_BODY: 'lifting_body',
    HYPERSONIC: 'HYPERSONIC',
    HIGH_ALTITUDE: 'HIGH_ALTITUDE',
    VTOL: "VTOL"
};

module.exports =  ExperimentalTypes ;
